
# diseasestats

<!-- badges: start -->
<!-- badges: end -->

The goal of diseasestats is to ...

## Installation

You can install the development version of diseasestats like so:

``` r
# FILL THIS IN! HOW CAN PEOPLE INSTALL YOUR DEV PACKAGE?
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(diseasestats)
## basic example code
```

